<div class="modal fade" id="add_university" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Adding Your University In this Website</h4>
        </div>
        <div class="modal-body">
            <h2>Adding Your University is too easy</h2>
            <hr>
            <h5>Just Follow this steps and you are very much good to go...</h5>
            <p>
                <ol>
                    <li>Register Yoursef as your university representator</li>
                    <li>Login as admin of your university</li>
                    <li>Add Your Depertment And Subject's</li>
                    <li>Come Back to the main Page</li>
                    <li>You Are DONE . Calculate and enjoy....</li>
                </ol>
            </p>
        </div>
    </div>
</div>
</div>