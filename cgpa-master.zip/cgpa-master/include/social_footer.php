<div class="footer-top">
    <div class="container">
        <div class="row">
            <div class="text-center">
                <a href="#" target="_blank"><i class="fb fa fa-facebook-square"></i></a>
                <a href="#" target="_blank"><i class=" fa fa-twitter-square"></i></a>
                <a href="#" target="_blank"><i class=" fa fa-instagram"></i></a>
                <a href="tel:+91-9148819457" target="_blank"><i class="ph fa fa-phone-square"></i></a>
            </div>
        </div>
    </div>
</div>
<?php
