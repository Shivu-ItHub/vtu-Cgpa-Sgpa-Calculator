<!-- My Level tearm Have to Be Dynamic -->

<table>
	<tr><td><a href="index.php">Home</a></td></tr>
	<tr><td><a href="profile.php">Profile</a></td></tr>
	<tr><td><a href="user_subject.php">Your Subjects</a></td></tr>
	<tr><td><a href="logout.php">Logout</a></td></tr>
</table>